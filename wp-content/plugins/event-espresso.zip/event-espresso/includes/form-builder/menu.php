<?php
echo '<p align="right"><a href="admin.php?page=form_builder&action=new_question">Add Question</a> | <a href="admin.php?page=form_builder">Edit Questions</a> | <a href="admin.php?page=form_groups&action=new_group">Add Group</a> | <a href="admin.php?page=form_groups">Edit Groups</a> </p>';
?>