<?php

$partner = "";//fill with the partnerID which we already offered you (required fields)
$security_code = "";//fill with the security key which we already offered you (required fields)

$sign_type = "MD5"; 
$transport= "http";

?>